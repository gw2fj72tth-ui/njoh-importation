NJOH IMPORTATION - Static Website
Files:
- index.html
- styles.css
- script.js

How to use:
1. Unzip the package and upload the files to any static hosting (GitHub Pages, Netlify, Vercel) or open index.html locally.
2. Edit contact phone, email or pricing in index.html to match your real details.
3. To host on GitHub Pages:
   - Create a new repository, push files to main branch, enable GitHub Pages in repo settings (use root).
4. To change colors: edit --blue in styles.css.

Contact for help: +237 654 097 409
